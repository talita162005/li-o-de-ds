﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace licaods
{
    public partial class frnPesquisaClient : Form
    {
        public frnPesquisaClient()
        {
            InitializeComponent();
        }

        private void tbclienteBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.tbclienteBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.cadastroDataSet);

        }

        private void frnPesquisaClient_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'cadastroDataSet.tbcliente' table. You can move, or remove it, as needed.
            this.tbclienteTableAdapter.Fill(this.cadastroDataSet.tbcliente);

        }
    }
}
